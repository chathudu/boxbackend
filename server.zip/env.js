module.exports = {
    EMAIL : 'bb1307814@gmail.com',
    PASSWORD :'drmzsorgxigcplar'
}